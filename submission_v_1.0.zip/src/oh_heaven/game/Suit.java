package oh_heaven.game;

public enum Suit
{
    SPADES, HEARTS, DIAMONDS, CLUBS
}
